#import <Flutter/Flutter.h>

@interface FlutterVlcPlayerPlugin : NSObject<FlutterPlugin>
@end
