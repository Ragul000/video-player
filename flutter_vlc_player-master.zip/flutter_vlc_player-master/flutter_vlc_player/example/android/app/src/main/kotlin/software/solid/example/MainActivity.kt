package software.solid.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
