enum VlcMediaEventType {
  opening,
  playing,
  paused,
  stopped,
  buffering,
  recording,
  timeChanged,
  mediaChanged,
  ended,
  unknown,
  error,
}
