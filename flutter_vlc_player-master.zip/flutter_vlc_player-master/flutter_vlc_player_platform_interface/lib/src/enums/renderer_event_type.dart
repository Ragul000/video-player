enum VlcRendererEventType {
  attached,
  detached,
  unknown,
}
